//
//  AppDelegate.h
//  foodapp
//
//  Created by Scott Waite on 10/5/13.
//  Copyright (c) 2013 Scott Waite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
