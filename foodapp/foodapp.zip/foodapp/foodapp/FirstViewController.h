//
//  FirstViewController.h
//  foodapp
//
//  Created by Scott Waite on 10/5/13.
//  Copyright (c) 2013 Scott Waite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController

@end
